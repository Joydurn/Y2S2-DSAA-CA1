Hi Mr Hubertus,
text files for process text should be placed
in the 'text' folder 

text files for opening thesauruses sohuld be placed in the 'thesaurus' folder

thanks :)