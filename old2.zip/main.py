# Jayden Yap p2112790 DAAA/2B/04 DSAA CA1 main.py
from gui import GUI

def main():
    gui=GUI()
    gui.welcomeMenu()

if __name__=='__main__':
    main()
else:
    print('Not Authorised')